package org.lunatech.dotty.using

final case class EngineConfig(initialSpeed: Int, maxSpeed: Int, label: String)