package org.lunatech.dotty.using

final case class Engine(name: String)