package org.lunatechlabs.multi

object Application extends App {
  println(s"$x $y $private_x $private_y")
}
