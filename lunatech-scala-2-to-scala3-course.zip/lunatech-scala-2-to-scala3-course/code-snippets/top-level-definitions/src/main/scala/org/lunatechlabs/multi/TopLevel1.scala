package org.lunatechlabs.multi

val x = 5
private val private_x = 27
