package org.lunatechlabs.multi

val y = 15
private val private_y = 730
